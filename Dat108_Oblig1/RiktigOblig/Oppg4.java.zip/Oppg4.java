package no.hvl.dat108;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Oppg4 {

	public static void ListeAvEtternavn(List<Ansatt> ansatte) {

		List<String> etternavn = ansatte.stream().map(a -> new String(a.getEtternavn())).collect(Collectors.toList());

		System.out.println(etternavn);

	}

	public static void FinnKvinner(List<Ansatt> ansatte) {

		List<Ansatt> Kvinnene = ansatte.stream().filter(a -> a.getKjonn().equals(Kjonn.Kvinne))
				.map(a -> new Ansatt(a.getFornavn(), a.getEtternavn(), a.getKjonn(), a.getStilling(), a.getAarslonn()))
				.collect(Collectors.toList());

		System.out.print(Kvinnene);
	}

	public static void gjennomsnittsLonnForKvinnene(List<Ansatt> ansatte) {

		double gjennomsnittLonn = ansatte.stream().filter(a -> a.getKjonn().equals(Kjonn.Kvinne))
				.mapToInt(a -> a.getAarslonn()).average().getAsDouble();

		System.out.println(gjennomsnittLonn);

	}

	public static int lonnOkningsForSjef(int tall) {

		return tall;
	}

	public static void lonnOkingForSjef(List<Ansatt> ansatte) {
		
		ansatte.stream()
		.filter(a -> a.getStilling().equals("Sjef"))
		.forEach(a -> { a.setAarslonn((a.getAarslonn() / 100 * 71) + a.getAarslonn());});

		System.out.println(ansatte);

	}

	public static void finneUtLonn(List<Ansatt> ansatte, int tall) {

		boolean funnet = ansatte.stream().anyMatch(a -> a.getAarslonn() > tall);

		System.out.println(funnet);
	}

	public static void skrivUtAlle(List<Ansatt> ansatte) {

		List<Ansatt> nyListe = ansatte.stream()
				.map(a -> new Ansatt(a.getFornavn(), a.getEtternavn(), a.getKjonn(), a.getStilling(), a.getAarslonn()))
				.collect(Collectors.toList());
		
		System.out.println(nyListe);

	}
	
	public static void lavestLonn(List<Ansatt> ansatte) {
		
		Optional<Ansatt> nyListe = ansatte.stream()
				.min(Comparator.comparing(Ansatt::getAarslonn));
		
		System.out.println(nyListe);
				
				
	}
	
	
	public static void FinnOgSkriv() {

		int j = 1;
		int sum = 0;
		
		for(int i = 0; i < 1000; i++) {
			
			if(j % 3 == 0) {
				
				sum += j;
				
			} else if(j % 5 == 0) {
				
				sum += j;
				
			}
			j++;
		}
		
		
		
		
		System.out.print(sum);
	}

	public static void main(String[] args) {

		List<Ansatt> ansatte = new ArrayList<Ansatt>();

		Ansatt a1 = new Ansatt("Isak", "Danielsen", Kjonn.Mann, "Assistant", 620000);
		Ansatt a2 = new Ansatt("Simon", "Jakobsen", Kjonn.Mann, "Sjef", 834000);
		Ansatt a3 = new Ansatt("Isabell", "Bjerk", Kjonn.Kvinne, "Assistant", 75400);
		Ansatt a4 = new Ansatt("Selma", "Ali", Kjonn.Kvinne, "Sjef", 760000);

		ansatte.add(a1);
		ansatte.add(a2);
		ansatte.add(a3);
		ansatte.add(a4);
		
		

//		ListeAvEtternavn(ansatte); 

//		FinnKvinner(ansatte);

//		gjennomsnittsLonnForKvinnene(ansatte);
		
//		lonnOkingForSjef(ansatte);

//		finneUtLonn(ansatte, 800000);
		
//		skrivUtAlle(ansatte);
		
//		lavestLonn(ansatte);
		
//		FinnOgSkriv();

		
	}

}
